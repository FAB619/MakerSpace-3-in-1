# Welcome to the translation team!

I am glad to have you here and I hope you will enjoy your time helping LaserGRBL project by translating into your language.
I know this whole thing may seem a bit hard at first, there is definitely a bit of a learning curve, but below you can find a set of guidelines that should make this process a little bit easier.

## Getting Started

There are some tools that you should definitly have to contribute with translation in a in an effective manner.
- A Git client for interact with github (download source code and submit your translation)
- A software for edit translation file

As Git client i suggest to download Github Desktop from here: https://desktop.github.com

To translate language files I suggest a good tool for editing resx is called ResEx, and could be downloaded here:
[ResExSetup1.2.zip](https://github.com/arkypita/LaserGRBL/files/909750/ResExSetup1.2.zip)

## Clone and download LaserGRBL source code
- Step one: login or register to github [(video tutorial)](https://www.youtube.com/watch?v=qxU4QvoMvkE)

... to be continue ...

