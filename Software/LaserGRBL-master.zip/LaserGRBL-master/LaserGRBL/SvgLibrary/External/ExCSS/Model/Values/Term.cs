﻿
// ReSharper disable once CheckNamespace
namespace ExCSS
{
    public abstract class Term
    {
        public static readonly InheritTerm Inherit = new InheritTerm();
    }
}
