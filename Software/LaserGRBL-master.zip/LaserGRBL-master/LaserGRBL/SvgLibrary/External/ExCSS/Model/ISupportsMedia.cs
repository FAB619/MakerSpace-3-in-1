﻿namespace ExCSS.Model
{
    interface ISupportsMedia
    {
        MediaTypeList Media { get; }
    }
}