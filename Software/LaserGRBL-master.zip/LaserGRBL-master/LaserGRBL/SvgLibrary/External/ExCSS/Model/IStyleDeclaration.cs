﻿namespace ExCSS.Model
{
    interface ISupportsDeclarations
    {
        StyleDeclaration Declarations { get; }
    }
}