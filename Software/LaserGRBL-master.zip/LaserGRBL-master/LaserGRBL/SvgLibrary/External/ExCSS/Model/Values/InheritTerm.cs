﻿using System;

namespace ExCSS
{
    public class InheritTerm : Term
    {
        internal InheritTerm()
        {
        }

        public override string ToString()
        {
            return "inherit";
        }
    }
}

