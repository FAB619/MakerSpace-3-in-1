﻿namespace ExCSS
{
    public interface IToString
    {
        string ToString(bool friendlyFormat, int indentation = 0);
    }
}