#
# mks_robin_pro.py
#
import robin
robin.prepare("0x08007000", "mks_robin_pro.ld", "Robin_pro.bin")
